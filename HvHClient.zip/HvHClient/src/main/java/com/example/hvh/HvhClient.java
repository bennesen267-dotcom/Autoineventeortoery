package com.example.hvh;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class HvhClient implements ClientModInitializer {
    private boolean nWasDown = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (SelfDestruct.done) return;
            long window = client.getWindow().getHandle();
            boolean down = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_N);
            if (down && !nWasDown && client.currentScreen == null && client.player != null) {
                client.setScreen(new MenuScreen());
            }
            nWasDown = down;
            AutoInventoryTotem.tick(client);
        });
    }
}
